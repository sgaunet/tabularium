just an ordinary archive
